#ifndef __CAN_H
#define __CAN_H
#include "stm32f10x.h"
#define CAN1_TX_Pin GPIO_Pin_12
#define CAN1_RX_Pin GPIO_Pin_11
#define CAN1_PORT	GPIOA

#define CAN2_TX_Pin GPIO_Pin_13
#define CAN2_RX_Pin GPIO_Pin_12
#define CAN2_PORT	GPIOB

void CAN_Config(void);

#endif
