#ifndef __ADC_H
#define __ADC_H

#define DMA_Data_size   3
#define ADC_DMA_CHANNEL DMA1_Channel1
#define ADC_IN1_Pin GPIO_Pin_0
#define ADC_IN2_Pin GPIO_Pin_1
#define ADC_IN3_Pin GPIO_Pin_2
#define ADC_Port		GPIOC

void ADC_Config(void);

#endif
