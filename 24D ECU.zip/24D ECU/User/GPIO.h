#ifndef __GPIO_H
#define __GPIO_H

#define Toggle(p,i)	 {p->ODR ^=i;}		//�����ת״̬

//LED-(LED0:PB0 LED1:PB1 LED2:PB2 LED3:PB10)
#define LED0_Pin 	GPIO_Pin_0
#define LED1_Pin 	GPIO_Pin_1
#define LED2_Pin  GPIO_Pin_2
#define LED3_Pin  GPIO_Pin_10

#define CAN1_RX_Toggle		Toggle(GPIOB,LED0_Pin)
#define CAN3_RX_Toggle		Toggle(GPIOB,LED1_Pin)
#define CAN3_TX_Toggle    Toggle(GPIOB,LED2_Pin)
#define CAN1_TX_Toggle  	Toggle(GPIOB,LED3_Pin)

//KEY-(KEY1:PB4	KEY2:PB3)
#define KEY1_Pin	GPIO_Pin_4
#define KEY2_Pin 	GPIO_Pin_3
#define KEY_PORT 	GPIOB

//ASMS-(ASMS:PB5)
#define ASMS_Pin 	GPIO_Pin_5
#define ASMS_Port GPIOB
#define ASMS		 	GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)

//SC_OUT(PB6-��ȫ��·���)
#define SC_OUT_Pin  GPIO_Pin_6
#define SC_OUT_Port GPIOB
#define SC_OUT			GPIO_ReadInputDataBit(SC_OUT_Port,SC_OUT_Pin)

//ASSI-(ASSI_1:PC11 ASSI_2:PC12)
//ASSI-1-YELLOW		ASSI-2-BLUE
#define ASSI_1_Pin  GPIO_Pin_11
#define ASSI_2_Pin  GPIO_Pin_12
#define ASSI_Port   GPIOC

#define NoneLight			GPIO_ResetBits(ASSI_Port,ASSI_1_Pin|ASSI_2_Pin);
#define YellowLight	  GPIO_SetBits(ASSI_Port,ASSI_1_Pin);GPIO_ResetBits(ASSI_Port,ASSI_2_Pin);
#define BlueLight			GPIO_SetBits(ASSI_Port,ASSI_2_Pin);GPIO_ResetBits(ASSI_Port,ASSI_1_Pin);
#define Yellow_Toggle Toggle(ASSI_Port,ASSI_1_Pin);GPIO_ResetBits(ASSI_Port,ASSI_2_Pin);
#define Blue_Toggle		Toggle(ASSI_Port,ASSI_2_Pin);GPIO_ResetBits(ASSI_Port,ASSI_1_Pin);
#define HuantingLight GPIO_SetBits(ASSI_Port,ASSI_1_Pin|ASSI_2_Pin);

//BEEP-(PB9)-�������
#define BEEP_Pin 	GPIO_Pin_9
#define BEEP_Port	GPIOB
#define BEEP_OFF	GPIO_SetBits(BEEP_Port,BEEP_Pin)
#define BEEP_ON 	GPIO_ResetBits(BEEP_Port,BEEP_Pin)
#define BEEP_Toggle  Toggle(BEEP_Port,BEEP_Pin)

//KEY_ENABLE-(PD2)
#define KEY_ENABLE_Pin	GPIO_Pin_2
#define KEY_ENABLE_Port GPIOD
#define KEY_ENABLE			GPIO_ReadInputDataBit(KEY_ENABLE_Port,KEY_ENABLE_Pin)

//ENABLELED-(PC13)-�������
#define ENABLELED_Pin  		GPIO_Pin_13
#define ENABLELED_Port 		GPIOC
#define ToDrive_LED_ON 		GPIO_ResetBits(ENABLELED_Port,ENABLELED_Pin);
#define ToDrive_LED_OFF 	GPIO_SetBits(ENABLELED_Port,ENABLELED_Pin);



void GPIO_Config(void);

#endif
