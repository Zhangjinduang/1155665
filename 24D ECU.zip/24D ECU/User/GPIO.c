#include "GPIO.h"
#include "stm32f10x.h"

/*���ȼ���KEY1:1-1-1; KEY2:1-1-1;ASMS:1-1-1;*/
//���İ��ϵĵ�
void LED_Config()
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_InitStruct.GPIO_Pin=LED0_Pin|LED1_Pin|LED2_Pin|LED3_Pin;
	GPIO_Init(GPIOB, &GPIO_InitStruct);
	GPIO_ResetBits(GPIOB,LED0_Pin|LED1_Pin|LED2_Pin|LED3_Pin);
}
//ѡģʽ����
void KEY_Config()
{
	GPIO_InitTypeDef GPIO_InitStruct;
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_Initstructure;
	
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO,ENABLE);
	//KEY1
	GPIO_InitStruct.GPIO_Pin=KEY1_Pin;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(KEY_PORT, &GPIO_InitStruct);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource4);
	EXTI_InitStructure.EXTI_Line = EXTI_Line4;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;		
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;	
	EXTI_InitStructure.EXTI_LineCmd = ENABLE; 				
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	NVIC_Initstructure.NVIC_IRQChannel=EXTI4_IRQn;
	NVIC_Initstructure.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_Initstructure.NVIC_IRQChannelSubPriority=1;
	NVIC_Initstructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_Initstructure);
	
//KEY2
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_AFIO,ENABLE);
	GPIO_InitStruct.GPIO_Pin=KEY2_Pin;
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(KEY_PORT, &GPIO_InitStruct);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource3);
	EXTI_InitStructure.EXTI_Line = EXTI_Line3;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;		
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;	
	EXTI_InitStructure.EXTI_LineCmd = ENABLE; 
	EXTI_Init(&EXTI_InitStructure);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	NVIC_Initstructure.NVIC_IRQChannel=EXTI3_IRQn;
	NVIC_Initstructure.NVIC_IRQChannelPreemptionPriority=1;
	NVIC_Initstructure.NVIC_IRQChannelSubPriority=1;
	NVIC_Initstructure.NVIC_IRQChannelCmd=ENABLE;
	NVIC_Init(&NVIC_Initstructure);
}

//ASMS������
void ASMS_Config()
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Pin=ASMS_Pin;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(ASMS_Port,&GPIO_InitStruct);
}
//ASSI����
void ASSI_Config()
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin=ASSI_1_Pin|ASSI_2_Pin;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(ASSI_Port,&GPIO_InitStruct);
	GPIO_ResetBits(ASSI_Port,ASSI_1_Pin|ASSI_2_Pin);
}
//����������
void BEEP_Config()
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin=BEEP_Pin;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(BEEP_Port,&GPIO_InitStruct);
	GPIO_SetBits(BEEP_Port,BEEP_Pin);
}
//ʹ�ܰ�������
void KEY_ENABLE_Config()
{
	GPIO_InitTypeDef GPIO_InitStruct;
//	EXTI_InitTypeDef EXTI_InitStructure;
//	NVIC_InitTypeDef NVIC_Initstructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD,ENABLE);
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Pin=KEY_ENABLE_Pin;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(KEY_ENABLE_Port,&GPIO_InitStruct);
//	/*EXTI*/
//	GPIO_EXTILineConfig(GPIO_PortSourceGPIOD,GPIO_PinSource2);
//	EXTI_InitStructure.EXTI_Line = EXTI_Line2;
//	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;		/* EXTI Ϊ�ж�ģʽ */
//	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;	/* �������ж� */
//	EXTI_InitStructure.EXTI_LineCmd = ENABLE; 				   /* ʹ���ж� */
//	EXTI_Init(&EXTI_InitStructure);
//	/*NVIC*/
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
//	NVIC_Initstructure.NVIC_IRQChannel=EXTI2_IRQn;
//	NVIC_Initstructure.NVIC_IRQChannelPreemptionPriority=1;
//	NVIC_Initstructure.NVIC_IRQChannelSubPriority=1;
//	NVIC_Initstructure.NVIC_IRQChannelCmd=ENABLE;
//	NVIC_Init(&NVIC_Initstructure);
}
//����ʹ�ܵ�
void ENABLE_LED_Config()
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Pin=ENABLELED_Pin;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(ENABLELED_Port,&GPIO_InitStruct);
	GPIO_SetBits(ENABLELED_Port,ENABLELED_Pin);
}
//ʹ�ܼ��
void SC_OUT_Config()
{
	GPIO_InitTypeDef GPIO_InitStruct;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitStruct.GPIO_Mode=GPIO_Mode_IN_FLOATING;
	GPIO_InitStruct.GPIO_Pin=SC_OUT_Pin;
	GPIO_InitStruct.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(SC_OUT_Port,&GPIO_InitStruct);
	GPIO_ResetBits(SC_OUT_Port,SC_OUT_Pin);
}
void GPIO_Config()
{
	LED_Config();
	KEY_Config();
	ASMS_Config();
	ASSI_Config();
	BEEP_Config();
	KEY_ENABLE_Config();
	ENABLE_LED_Config();
	SC_OUT_Config();
}
