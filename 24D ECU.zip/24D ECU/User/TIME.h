#ifndef __TIME_H
#define __TIME_H

void TIME_Config(void);
#endif

